module ActiveRecord
  module DatabaseValidations
    VERSION = "0.2.4"
  end
end
